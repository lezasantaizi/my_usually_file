The files 
  * msvc120engmatopts.bat
  * msvc120opts.bat
  * msvc120opts.stp
should be copied to C:\Program Files\MATLAB\R2013a\bin\win64\mexopts .

The files 
  * msvc120compp.bat
  * msvc120compp.stp
should be copied to C:\Program Files\MATLAB\R2013a\bin\win64\mbuildopts .

